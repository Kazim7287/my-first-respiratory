class GameLogic {
  List<List<String>> board =
      List.generate(3, (_) => List.generate(3, (_) => ''));
  bool _isXTurn = true;

  bool makeMove(int row, int col) {
    if (board[row][col].isEmpty) {
      board[row][col] = _isXTurn ? 'X' : 'O';
      _isXTurn = !_isXTurn;
      return true;
    }
    return false;
  }

  String? checkWinner() {
    // Check rows
    for (var row in board) {
      if (row[0] == row[1] && row[1] == row[2] && row[0].isNotEmpty) {
        return row[0];
      }
    }
    // Check columns
    for (int col = 0; col < 3; col++) {
      if (board[0][col] == board[1][col] &&
          board[1][col] == board[2][col] &&
          board[0][col].isNotEmpty) {
        return board[0][col];
      }
    }
    // Check diagonals
    if (board[0][0] == board[1][1] &&
        board[1][1] == board[2][2] &&
        board[0][0].isNotEmpty) {
      return board[0][0];
    }
    if (board[0][2] == board[1][1] &&
        board[1][1] == board[2][0] &&
        board[0][2].isNotEmpty) {
      return board[0][2];
    }
    return null;
  }

  void resetBoard() {
    board = List.generate(3, (_) => List.generate(3, (_) => ''));
    _isXTurn = true;
  }
}
