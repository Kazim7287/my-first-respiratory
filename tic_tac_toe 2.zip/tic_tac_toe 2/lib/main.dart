import 'package:flutter/material.dart';
import 'screens/game_screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isDarkMode = false;

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Removes the debug banner
      theme: _isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: GameScreen(toggleTheme: _toggleTheme, isDarkMode: _isDarkMode),
    );
  }
}
