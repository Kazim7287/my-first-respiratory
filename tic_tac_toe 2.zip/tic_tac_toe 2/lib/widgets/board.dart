import 'package:flutter/material.dart';
import '../utils/game_logic.dart';
import '../widgets/cell.dart';

class Board extends StatefulWidget {
  final String playerXName;
  final String playerOName;
  final void Function(String) onWin;

  Board({
    required this.playerXName,
    required this.playerOName,
    required this.onWin,
    Key? key,
  }) : super(key: key);

  @override
  BoardState createState() => BoardState();
}

class BoardState extends State<Board> {
  final GameLogic _gameLogic = GameLogic();
  String? _winner;

  void _handleTap(int row, int col) {
    setState(() {
      if (_gameLogic.makeMove(row, col)) {
        String? winnerSymbol = _gameLogic.checkWinner();
        if (winnerSymbol != null) {
          _winner =
              winnerSymbol == 'X' ? widget.playerXName : widget.playerOName;
          widget.onWin(_winner!);
        }
      }
    });
  }

  void resetBoard() {
    setState(() {
      _gameLogic.resetBoard();
      _winner = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ...List.generate(3, (row) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(3, (col) {
              return Padding(
                padding: const EdgeInsets.all(4.0),
                child: Cell(
                  value: _gameLogic.board[row][col],
                  onTap: () => _handleTap(row, col),
                ),
              );
            }),
          );
        }),
      ],
    );
  }
}
