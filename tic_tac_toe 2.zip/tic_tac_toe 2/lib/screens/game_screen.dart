import 'package:flutter/material.dart';
import '../widgets/board.dart';

class GameScreen extends StatefulWidget {
  final void Function() toggleTheme;
  final bool isDarkMode;

  GameScreen({required this.toggleTheme, required this.isDarkMode});

  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  final TextEditingController _playerXController = TextEditingController();
  final TextEditingController _playerOController = TextEditingController();
  String _playerXName = 'Player X';
  String _playerOName = 'Player O';
  AnimationController? _animationController;
  Animation<double>? _animation;
  String? _winner;
  final GlobalKey<BoardState> _boardKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _animationController!,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _animationController?.dispose();
    super.dispose();
  }

  void _showWinner(String winner) {
    setState(() {
      _winner = winner;
    });
    _animationController?.forward().then((_) {
      Future.delayed(Duration(seconds: 2), () {
        _animationController?.reset();
        setState(() {
          _winner = null;
        });
      });
    });
  }

  void _restartGame() {
    setState(() {
      _winner = null;
    });
    _boardKey.currentState?.resetBoard();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: widget.isDarkMode ? Colors.black : Colors.blueAccent,
        title: Text(
          'Tic Tac Toe',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(widget.isDarkMode ? Icons.wb_sunny : Icons.nights_stay),
            onPressed: widget.toggleTheme,
          ),
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _restartGame,
          ),
        ],
      ),
      body: Container(
        color: widget.isDarkMode
            ? const Color.fromARGB(255, 9, 3, 3)
            : const Color.fromARGB(255, 129, 179, 229),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _playerXController,
                decoration: InputDecoration(
                  labelText: 'Player X Name',
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor:
                      widget.isDarkMode ? Colors.grey[700] : Colors.white,
                ),
                style: TextStyle(
                    color: widget.isDarkMode ? Colors.white : Colors.black),
                onChanged: (value) {
                  setState(() {
                    _playerXName = value;
                  });
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _playerOController,
                decoration: InputDecoration(
                  labelText: 'Player O Name',
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor:
                      widget.isDarkMode ? Colors.grey[700] : Colors.white,
                ),
                style: TextStyle(
                    color: widget.isDarkMode ? Colors.white : Colors.black),
                onChanged: (value) {
                  setState(() {
                    _playerOName = value;
                  });
                },
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color:
                          widget.isDarkMode ? Colors.grey[800] : Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: widget.isDarkMode
                              ? Colors.black.withOpacity(0.5)
                              : Colors.black.withOpacity(0.1),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Board(
                      key: _boardKey,
                      playerXName: _playerXName,
                      playerOName: _playerOName,
                      onWin: _showWinner,
                    ),
                  ),
                  if (_winner != null)
                    ScaleTransition(
                      scale: _animation!,
                      child: Container(
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: widget.isDarkMode
                              ? Colors.blueAccent
                              : Colors.greenAccent,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Text(
                          'Congratulations, $_winner!',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color:
                                widget.isDarkMode ? Colors.white : Colors.black,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
