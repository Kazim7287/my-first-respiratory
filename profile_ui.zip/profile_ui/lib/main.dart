import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isDarkMode = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Disable the debug banner
      theme: isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: ProfilePage(
        isDarkMode: isDarkMode,
        toggleTheme: () {
          setState(() {
            isDarkMode = !isDarkMode;
          });
        },
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final bool isDarkMode;
  final Function toggleTheme;

  ProfilePage({required this.isDarkMode, required this.toggleTheme});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        actions: [
          IconButton(
            icon: Icon(isDarkMode ? Icons.wb_sunny : Icons.nights_stay),
            onPressed: () {
              toggleTheme();
            },
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Container(
            width: double.infinity,
            color: Colors.blue,
            padding: EdgeInsets.symmetric(vertical: 32),
            child: Column(
              children: <Widget>[
                CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('images/kazim.jpeg'),
                ),
                SizedBox(height: 16),
                Text(
                  'Muhammad Kazim Ahmad',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'Software Developer',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(16),
              children: <Widget>[
                // Section for Email
                ListTile(
                  leading: Icon(Icons.email),
                  title: Text('Kazim@gmail.com'),
                  onTap: () {},
                ),
                Divider(),
                // Section for Phone
                ListTile(
                  leading: Icon(Icons.phone),
                  title: Text('+923159524108'),
                  onTap: () {},
                ),
                Divider(),
                // Section for Profile Settings
                ListTile(
                  leading: Icon(Icons.settings),
                  title: Text('Profile Settings'),
                  onTap: () {
                    // Handle profile settings logic here
                  },
                ),
                Divider(),
                // Section for Profile Details
                ListTile(
                  leading: Icon(Icons.info),
                  title: Text('Profile Details'),
                  onTap: () {
                    // Handle profile details logic here
                  },
                ),
                Divider(),
                // Section for Logout
                ListTile(
                  leading: Icon(Icons.logout),
                  title: Text('Logout'),
                  onTap: () {
                    // Handle logout logic here
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
