import 'package:flutter/material.dart';

class AppTextStyles {
  static const TextStyle title =
      TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold);
  static const TextStyle player =
      TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold);
}
