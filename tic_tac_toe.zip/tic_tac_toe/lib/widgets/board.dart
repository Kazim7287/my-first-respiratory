import 'package:flutter/material.dart';
import '../widgets/cell.dart';
import '../utils/game_logic.dart';

class Board extends StatefulWidget {
  @override
  _BoardState createState() => _BoardState();
}

class _BoardState extends State<Board> {
  final GameLogic _gameLogic = GameLogic();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (row) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(3, (col) {
            return Cell(
              value: _gameLogic.board[row][col],
              onTap: () {
                setState(() {
                  _gameLogic.makeMove(row, col);
                });
              },
            );
          }),
        );
      }),
    );
  }
}
