import 'package:flutter/material.dart';

class Cell extends StatelessWidget {
  final String value;
  final VoidCallback onTap;

  Cell({required this.value, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.all(4.0),
        width: 80.0,
        height: 80.0,
        decoration: BoxDecoration(
          color: Colors.blue[100],
          border: Border.all(color: Colors.blue, width: 2.0),
        ),
        child: Center(
          child: Text(
            value,
            style: TextStyle(fontSize: 32.0, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
