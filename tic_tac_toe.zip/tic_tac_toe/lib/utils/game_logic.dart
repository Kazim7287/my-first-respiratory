class GameLogic {
  List<List<String>> board =
      List.generate(3, (_) => List.generate(3, (_) => ''));

  String currentPlayer = 'X';

  void makeMove(int row, int col) {
    if (board[row][col] == '') {
      board[row][col] = currentPlayer;
      if (checkWinner(row, col)) {
        print('$currentPlayer wins!');
        resetBoard();
      } else if (board.expand((e) => e).every((cell) => cell.isNotEmpty)) {
        print('It\'s a draw!');
        resetBoard();
      } else {
        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
      }
    }
  }

  bool checkWinner(int row, int col) {
    return (board[row].every((cell) => cell == currentPlayer) || // Row
        board.every((r) => r[col] == currentPlayer) || // Column
        (row == col &&
            board.every(
                (r) => r[board.indexOf(r)] == currentPlayer)) || // Diagonal
        (row + col == 2 &&
            board.every((r) =>
                r[2 - board.indexOf(r)] == currentPlayer))); // Anti-diagonal
  }

  void resetBoard() {
    board = List.generate(3, (_) => List.generate(3, (_) => ''));
    currentPlayer = 'X';
  }
}
